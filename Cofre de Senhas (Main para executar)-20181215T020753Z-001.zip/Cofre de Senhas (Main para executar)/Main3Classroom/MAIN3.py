import lendo        #criamos essa biblioteca para ler o dicionário no arquivo "SenhasBD.txt"
import escrevendo   #essa escreve o dicionário no arquivo "SenhasBD.txt"
import seguranca    #essa codifica e decodifica as nossas senhas usando a senha MESTRE!

try:            #tentamos ler o dicionário
    SenhasDict = lendo.ler()
except FileNotFoundError: #se não acharmos o dicionário, criamos um dentro do programa.
    print("Senhas não encontradas! Criando novo banco de senhas")
    SenhasDict = {} #aqui o nosso novo dicionário de senhas.
    
print('insira a senha master!')
senhaMaster = input()   #pedimos pela senha mestre
while(True):            #enquanto o usuário escolher 1 ou 2, teremos esse loop infinito
    print("""Você deseja:
        1. Acessar uma senha?
        2. Cadastrar uma senha nova?""") #string multilinha, muito melhor do que usar \n
    escolha = int(input())

    if (escolha == 1): #usuário escolhe 1, o código identado abaixo é executado
        print('qual senha deseja acessar?')
        busca = input()
        if busca in SenhasDict:
            print(seguranca.decode(senhaMaster, SenhasDict[busca])) #DESCRIPTOGRAFA a busca
        else:
            print('Não existe senha para a conta '+busca)
    if (escolha == 2): #usuário escolhe 2, o código identado abaixo é executado
        print('qual o nome que deseja dar para senha? ex: facebook')
        nome = input() #o usuário insere a nova conta
        print('qual a senha que deseja guardar para este nome?')
        senha = input() #o usuário insere a nova senha
        SenhasDict[nome] = seguranca.encode(senha, senhaMaster) #insere no dicionário CRIPTOGRAFADO
        escrevendo.escrever(SenhasDict)
    elif (escolha != 1 and escolha != 2):
        break
    
