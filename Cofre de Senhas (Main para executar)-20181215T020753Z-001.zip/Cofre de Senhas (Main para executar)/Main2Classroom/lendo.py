import ast

def ler():
    with open('SenhasBD.txt') as arquivo: #abrimos 'SenhasBD' e apelidamos como arquivo
        texto = arquivo.read()
        dic = ast.literal_eval(texto)
        return dic






