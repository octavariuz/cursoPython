import lendo
import escrevendo
import seguranca

try:
    SenhasDict = lendo.ler()
except FileNotFoundError:
    print("Senhas não encontradas! Criando novo banco de senhas")
    SenhasDict = {}
    
print('insira a senha master!')
senhaMaster = input()
print("""Você deseja:
    1. Acessar uma senha?
    2. Cadastrar uma senha nova?""") #string multilinha, muito melhor do que usar \n
escolha = int(input())

if (escolha == 1):
    print('qual senha deseja acessar?')
    busca = input()
    if busca in SenhasDict:
        print(seguranca.decode(senhaMaster, SenhasDict[busca])) #DESCRIPTOGRAFA a busca
    else:
        print('Não existe senha para a conta '+busca)
if (escolha == 2):
    print('qual o nome que deseja dar para senha? ex: facebook')
    nome = input() #o usuário insere a nova conta
    print('qual a senha que deseja guardar para este nome?')
    senha = input() #o usuário insere a nova senha
    SenhasDict[nome] = seguranca.encode(senhaMaster, senha) #insere no dicionário CRIPTOGRAFADO
    escrevendo.escrever(SenhasDict)
    
